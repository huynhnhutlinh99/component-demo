import React from 'react';

function DemoProps(props) {
    return( 
        //tạo một props tên là name
        <h1>Hello, {props.name}</h1>
    );
}

export default DemoProps;